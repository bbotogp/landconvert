# Land Converter (Flutter)

This bundle includes:
- `pubspec.yaml`
- `lib/main.dart`
- Quick steps to build a **Debug** or **Release** APK.

## 1) Create project
```bash
flutter create land_converter
cd land_converter
```

## 2) Replace files
Overwrite the generated files with the ones in this bundle:

- Replace `pubspec.yaml` with the provided one.
- Create folder `lib` (if not exists) and replace `lib/main.dart` with the provided one.

## 3) Get packages
```bash
flutter pub get
```

## 4) Build a quick Debug APK (no signing required)
```bash
flutter build apk --debug
```
Find it at: `build/app/outputs/flutter-apk/app-debug.apk`

## 5) Build a signed Release APK
1. Create a keystore (one-time):
```bash
keytool -genkey -v -keystore keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias land
```
Move `keystore.jks` to `android/` folder.

2. Create `android/key.properties` with your values:
```
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=land
storeFile=keystore.jks
```

3. Edit `android/app/build.gradle` and add:
```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    defaultConfig {
        applicationId "com.example.landconverter" // change if you like
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
            shrinkResources false
        }
    }
}
```

4. Build split-per-ABI release (smaller APKs):
```bash
flutter build apk --release --split-per-abi
```
Artifacts:
- `build/app/outputs/flutter-apk/app-arm64-v8a-release.apk`
- `build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk`
- `build/app/outputs/flutter-apk/app-x86_64-release.apk`

Or a single universal release:
```bash
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

## 6) Install on device
- Enable "Install unknown apps" on your Android device.
- Connect via USB and run:
```bash
adb install -r build/app/outputs/flutter-apk/app-debug.apk
```
(or choose the release APK path).

Enjoy!
