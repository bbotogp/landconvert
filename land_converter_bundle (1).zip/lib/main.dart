import 'package:flutter/material.dart';

void main() {
  runApp(const LandConverterApp());
}

/// ===============================
///  Land Converter – Flutter App
///  - Global + Yemeni units
///  - Country switch
///  - Editable Yemeni factors
/// ===============================
class LandConverterApp extends StatelessWidget {
  const LandConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Land Converter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}

/// Countries supported (room to add more later)
enum Country { yemen, global }

/// Unit model
class AreaUnit {
  final String key;           // unique id
  final String nameEn;        // English label
  final String nameAr;        // Arabic label
  final bool yemenOnly;       // show only when Yemen selected
  double factorToM2;          // 1 unit = factorToM2 m² (editable for Yemeni units)

  AreaUnit({
    required this.key,
    required this.nameEn,
    required this.nameAr,
    required this.factorToM2,
    this.yemenOnly = false,
  });

  String displayLabel(bool arabic) => arabic ? nameAr : nameEn;
}

/// Default factors (m² is base = 1.0)
/// NOTE on Yemeni units:
/// - Values can vary by region; we provide sensible defaults and allow editing in-app.
/// - Defaults here reflect commonly cited Sana'a presets:
///   Lebna ≈ 44.4 m²; Ma'ad = 40 Lebna ≈ 1,776 m²; Qosbah (قصبة مربعة) ≈ 3.385 m² (placeholder).
class UnitsRepo {
  final List<AreaUnit> all = [
    AreaUnit(key: 'm2', nameEn: 'Square Meter (m²)', nameAr: 'متر مربع (م²)', factorToM2: 1.0),
    AreaUnit(key: 'km2', nameEn: 'Square Kilometer (km²)', nameAr: 'كيلومتر مربع (كم²)', factorToM2: 1000000.0),
    AreaUnit(key: 'ha', nameEn: 'Hectare (ha)', nameAr: 'هكتار (هـ)', factorToM2: 10000.0),
    AreaUnit(key: 'a', nameEn: 'Are (a)', nameAr: 'آر', factorToM2: 100.0),
    AreaUnit(key: 'acre', nameEn: 'Acre', nameAr: 'أكر', factorToM2: 4046.8564224),
    AreaUnit(key: 'feddan', nameEn: 'Feddan', nameAr: 'فدان', factorToM2: 4200.0),
    AreaUnit(key: 'yd2', nameEn: 'Square Yard (yd²)', nameAr: 'ياردة مربعة (ياردة²)', factorToM2: 0.83612736),
    AreaUnit(key: 'ft2', nameEn: 'Square Foot (ft²)', nameAr: 'قدم مربع (قدم²)', factorToM2: 0.09290304),

    // Yemeni traditional (defaults editable in settings)
    AreaUnit(key: 'lebna', nameEn: 'Lebna (Yemen)', nameAr: 'لبنة (اليمن)', factorToM2: 44.4, yemenOnly: true),
    AreaUnit(key: 'maad',  nameEn: 'Ma’ad (Yemen)', nameAr: 'معاد (اليمن)',  factorToM2: 44.4 * 40, yemenOnly: true),
    AreaUnit(key: 'qosbah',nameEn: 'Qosbah² (Yemen)', nameAr: 'قصبة مربعة (اليمن)', factorToM2: 3.385, yemenOnly: true),
  ];

  List<AreaUnit> available(Country c) =>
      all.where((u) => !u.yemenOnly || c == Country.yemen).toList();

  AreaUnit byKey(String key) => all.firstWhere((u) => u.key == key);
}

/// Simple localization toggle (we keep both labels on UI but align RTL where needed)
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final UnitsRepo repo = UnitsRepo();

  Country selectedCountry = Country.yemen;
  bool arabic = true;

  late AreaUnit fromUnit;
  late AreaUnit toUnit;
  final TextEditingController inputCtrl = TextEditingController(text: '1');

  double? result;

  @override
  void initState() {
    super.initState();
    final units = repo.available(selectedCountry);
    fromUnit = units.firstWhere((u) => u.key == 'lebna', orElse: () => units.first);
    toUnit   = units.firstWhere((u) => u.key == 'm2', orElse: () => units[1]);
    _recalc();
  }

  void _recalc() {
    final v = double.tryParse(inputCtrl.text.replaceAll(',', '.'));
    if (v == null) {
      setState(() => result = null);
      return;
    }
    // value in m²
    final inM2 = v * fromUnit.factorToM2;
    // convert to target
    final out  = inM2 / toUnit.factorToM2;
    setState(() => result = out);
  }

  @override
  Widget build(BuildContext context) {
    final units = repo.available(selectedCountry);

    return Directionality(
      textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(arabic ? 'محول الأراضي' : 'Land Converter'),
          actions: [
            IconButton(
              tooltip: arabic ? 'تبديل اللغة' : 'Toggle Language',
              onPressed: () => setState(() => arabic = !arabic),
              icon: const Icon(Icons.translate),
            ),
            IconButton(
              tooltip: arabic ? 'إعدادات الوحدات اليمنية' : 'Yemeni Units Settings',
              onPressed: _openYemenSettings,
              icon: const Icon(Icons.tune),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Country selector
            Row(
              children: [
                const Icon(Icons.public),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<Country>(
                    value: selectedCountry,
                    decoration: InputDecoration(
                      labelText: arabic ? 'الدولة' : 'Country',
                      border: const OutlineInputBorder(),
                    ),
                    items: [
                      DropdownMenuItem(
                        value: Country.yemen,
                        child: Text(arabic ? 'اليمن' : 'Yemen'),
                      ),
                      DropdownMenuItem(
                        value: Country.global,
                        child: Text(arabic ? 'عالمي' : 'Global'),
                      ),
                    ],
                    onChanged: (c) {
                      if (c == null) return;
                      setState(() {
                        selectedCountry = c;
                        // reset unit lists to safe defaults
                        final av = repo.available(selectedCountry);
                        fromUnit = av.first;
                        toUnit = av.firstWhere((u) => u.key == 'm2', orElse: () => av[1]);
                        _recalc();
                      });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // From / To selectors
            Row(
              children: [
                Expanded(child: _unitPicker(units, true)),
                const SizedBox(width: 12),
                IconButton(
                  onPressed: () {
                    setState(() {
                      final swap = fromUnit;
                      fromUnit = toUnit;
                      toUnit = swap;
                      _recalc();
                    });
                  },
                  icon: const Icon(Icons.swap_horiz),
                  tooltip: arabic ? 'تبديل' : 'Swap',
                ),
                const SizedBox(width: 12),
                Expanded(child: _unitPicker(units, false)),
              ],
            ),
            const SizedBox(height: 16),

            // Input
            TextField(
              controller: inputCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: arabic ? 'القيمة' : 'Value',
                border: const OutlineInputBorder(),
                suffixText: fromUnit.displayLabel(arabic),
              ),
              onChanged: (_) => _recalc(),
            ),

            const SizedBox(height: 16),

            // Result card
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: result == null
                    ? Text(
                        arabic ? 'يرجى إدخال رقم صحيح' : 'Please enter a valid number',
                        style: TextStyle(color: Theme.of(context).colorScheme.error),
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            arabic ? 'النتيجة' : 'Result',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 8),
                          SelectableText(
                            '${inputCtrl.text} ${fromUnit.displayLabel(arabic)}  =  '
                            '${_format(result!)}  ${toUnit.displayLabel(arabic)}',
                            style: Theme.of(context).textTheme.headlineSmall,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            arabic
                                ? 'المعاملات اليمنية قابلة للتعديل من أيقونة الإعدادات (اختلافات إقليمية).'
                                : 'Yemeni factors are editable in Settings (regional variations).',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
              ),
            ),

            const SizedBox(height: 24),

            // Sections list (visual like your screenshot)
            _sectionTile(
              color: Colors.green,
              titleEn: 'Land Area',
              titleAr: 'المساحة',
              subtitle: arabic ? 'm², km², cm², dm²' : 'm², km², cm², dm²',
            ),
            _sectionTile(
              color: Colors.indigo,
              titleEn: 'Acreage',
              titleAr: 'الفدان والأكر',
              subtitle: arabic ? 'فدان، أكر' : 'Feddan, Acre',
            ),
            _sectionTile(
              color: Colors.orange,
              titleEn: 'Global Units',
              titleAr: 'الوحدات العالمية',
              subtitle: arabic ? 'هكتار، آر، ياردة²، قدم²' : 'Hectare, Are, yd², ft²',
            ),
            _sectionTile(
              color: Colors.red,
              titleEn: 'Irregular Land',
              titleAr: 'الأراضي غير المنتظمة',
              subtitle: arabic ? '٣ أضلاع، ٤ أضلاع، مضلع' : '3 sides, 4 sides, polygon',
            ),
            if (selectedCountry == Country.yemen)
              _sectionTile(
                color: Colors.amber,
                titleEn: 'Yemeni Units',
                titleAr: 'الوحدات اليمنية',
                subtitle: arabic ? 'لبنة، معاد، قصبة مربعة' : 'Lebna, Ma’ad, Qosbah²',
              ),
          ],
        ),
      ),
    );
  }

  Widget _unitPicker(List<AreaUnit> units, bool isFrom) {
    final label = isFrom ? (arabic ? 'من' : 'From') : (arabic ? 'إلى' : 'To');
    final selected = isFrom ? fromUnit : toUnit;
    return DropdownButtonFormField<AreaUnit>(
      value: selected,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      items: units
          .map((u) => DropdownMenuItem(
                value: u,
                child: Text('${u.displayLabel(arabic)}'),
              ))
          .toList(),
      onChanged: (u) {
        if (u == null) return;
        setState(() {
          if (isFrom) {
            fromUnit = u;
          } else {
            toUnit = u;
          }
          _recalc();
        });
      },
    );
  }

  Widget _sectionTile({
    required Color color,
    required String titleEn,
    required String titleAr,
    required String subtitle,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color, child: const Icon(Icons.crop_square, color: Colors.white)),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(arabic ? titleAr : titleEn, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(arabic ? titleEn : titleAr, style: const TextStyle(color: Colors.black54)),
          ],
        ),
        subtitle: Text(subtitle),
      ),
    );
  }

  String _format(double v) {
    if (v.isNaN || v.isInfinite) return '-';
    if (v.abs() >= 1000000) return v.toStringAsFixed(2);
    if (v.abs() >= 1000) return v.toStringAsFixed(3);
    if (v.abs() >= 1) return v.toStringAsFixed(4);
    return v.toStringAsFixed(6);
  }

  void _openYemenSettings() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => YemenSettingsSheet(
        arabic: arabic,
        repo: repo,
        onSaved: () {
          setState(() {});
          _recalc();
        },
      ),
    );
  }
}

class YemenSettingsSheet extends StatefulWidget {
  final bool arabic;
  final UnitsRepo repo;
  final VoidCallback onSaved;

  const YemenSettingsSheet({
    super.key,
    required this.arabic,
    required this.repo,
    required this.onSaved,
  });

  @override
  State<YemenSettingsSheet> createState() => _YemenSettingsSheetState();
}

class _YemenSettingsSheetState extends State<YemenSettingsSheet> {
  late TextEditingController lebnaCtrl;
  late TextEditingController maadCtrl;
  late TextEditingController qosbahCtrl;

  @override
  void initState() {
    super.initState();
    lebnaCtrl  = TextEditingController(text: widget.repo.byKey('lebna').factorToM2.toString());
    maadCtrl   = TextEditingController(text: widget.repo.byKey('maad').factorToM2.toString());
    qosbahCtrl = TextEditingController(text: widget.repo.byKey('qosbah').factorToM2.toString());
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.arabic;
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16, right: 16, top: 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(a ? 'إعدادات الوحدات اليمنية' : 'Yemeni Units Settings',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          _numField(a ? 'لبنة (م² لكل لبنة)' : 'Lebna (m² per unit)', lebnaCtrl),
          const SizedBox(height: 8),
          _numField(a ? 'معاد (م² لكل معاد)' : 'Ma’ad (m² per unit)', maadCtrl),
          const SizedBox(height: 8),
          _numField(a ? 'قصبة مربعة (م² لكل قصبة²)' : 'Qosbah² (m² per unit)', qosbahCtrl),
          const SizedBox(height: 12),
          Row(
            children: [
              TextButton(
                onPressed: _restoreDefaults,
                child: Text(a ? 'استعادة الافتراضي' : 'Restore defaults'),
              ),
              const Spacer(),
              FilledButton(
                onPressed: _save,
                child: Text(a ? 'حفظ' : 'Save'),
              ),
            ],
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _numField(String label, TextEditingController c) {
    return TextField(
      controller: c,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
    );
  }

  void _restoreDefaults() {
    setState(() {
      lebnaCtrl.text  = '44.4';
      maadCtrl.text   = (44.4 * 40).toStringAsFixed(1);
      qosbahCtrl.text = '3.385';
    });
  }

  void _save() {
    double? lebna = double.tryParse(lebnaCtrl.text.replaceAll(',', '.'));
    double? maad = double.tryParse(maadCtrl.text.replaceAll(',', '.'));
    double? qosbah = double.tryParse(qosbahCtrl.text.replaceAll(',', '.'));

    if ([lebna, maad, qosbah].any((v) => v == null || v! <= 0)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(widget.arabic ? 'يرجى إدخال قيم صحيحة' : 'Please enter valid values')),
      );
      return;
    }

    widget.repo.byKey('lebna').factorToM2 = lebna!;
    widget.repo.byKey('maad').factorToM2 = maad!;
    widget.repo.byKey('qosbah').factorToM2 = qosbah!;
    widget.onSaved();
    Navigator.pop(context);
  }
}
