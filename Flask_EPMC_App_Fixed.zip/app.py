# ✅ Flask App: Google Scholar + Save Sessions + Translation (Sandbox Compatible)

from flask import Flask, request, render_template_string, send_file, redirect, url_for
import requests, sqlite3, time, re
from lxml import etree
from datetime import datetime
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from deep_translator import GoogleTranslator

app = Flask(__name__)

# SQLite setup
conn = sqlite3.connect("search_log.db", check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS searches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query TEXT, lang TEXT, email TEXT, date TIMESTAMP
)''')
c.execute('''CREATE TABLE IF NOT EXISTS results (
    search_id INTEGER, sentence TEXT, citation TEXT, doi TEXT, gs_link TEXT, sci_hub_link TEXT,
    FOREIGN KEY(search_id) REFERENCES searches(id)
)''')
conn.commit()

HEADERS = {"User-Agent": "MedIntroBot/1.0 (mailto:example@example.com)"}
TRANSLATE = lambda text, lang: GoogleTranslator(source='auto', target=lang).translate(text)

def fetch_20_sentences(query, year_filter=None, country_filter=None):
    url = f"https://www.ebi.ac.uk/europepmc/webservices/rest/search?query={query}&format=json&resultType=core&pageSize=100&sortDate=y"
    try:
        r = requests.get(url).json()
    except:
        return []
    results = []
    for result in r.get('resultList', {}).get('result', []):
        title = result.get('title', '')
        abstract = result.get('abstractText', '')
        authors = result.get('authorString', 'No authors')
        year = result.get('pubYear', '')
        source = result.get('journalTitle', 'N/A')
        country = result.get('country', 'N/A')
        pmid = result.get('id', '')
        doi = result.get('doi', '')
        link = f"https://europepmc.org/article/MED/{pmid}"
        sci_hub_link = f"https://sci-hub.se/{doi}" if doi else "غير متاح"
        gs_link = f"https://scholar.google.com/scholar?q={title}"
        citation = f"{authors} ({year}). {title}. {source}. {country}."
        if year_filter and year != year_filter:
            continue
        if country_filter and country_filter.lower() != country.lower():
            continue
        if abstract:
            for sentence in abstract.split('.'):
                sentence = sentence.strip()
                if len(sentence) > 50:
                    results.append({
                        'sentence': sentence + '.',
                        'citation': citation,
                        'link': link,
                        'doi': doi,
                        'sci_hub_link': sci_hub_link,
                        'gs_link': gs_link,
                        'title': title
                    })
                    if len(results) >= 20:
                        return results
    return results

def summarize_results(results):
    return "\n".join(f"- {r['sentence']} (Source: {r['citation']})" for r in results)

@app.route('/', methods=['GET', 'POST'])
def index():
    query = request.form.get('query', '')
    year = request.form.get('year', '')
    country = request.form.get('country', '')
    email = request.form.get('email', '')
    lang = request.form.get('lang', 'ar')
    summarize = request.form.get('summarize', '')
    to_translate = request.form.get('translate', '')
    results = []

    if request.method == 'POST' and query:
        results = fetch_20_sentences(query, year_filter=year, country_filter=country)
        c.execute("INSERT INTO searches (query, lang, email, date) VALUES (?, ?, ?, ?)", (query, lang, email, datetime.now()))
        search_id = c.lastrowid
        for r in results:
            c.execute("INSERT INTO results (search_id, sentence, citation, doi, gs_link, sci_hub_link) VALUES (?, ?, ?, ?, ?, ?)",
                      (search_id, r['sentence'], r['citation'], r['doi'], r['gs_link'], r['sci_hub_link']))
        conn.commit()

        if summarize:
            return f"<pre>{summarize_results(results)}</pre><a href='/'>🔙 العودة</a>"

        if to_translate:
            for r in results:
                r['sentence'] = TRANSLATE(r['sentence'], 'ar' if lang == 'ar' else 'en')

    return render_template_string("<h1>🧪 نتائج البحث</h1><ul>{% for r in results %}<li>{{ r['sentence'] }}<br><a href='{{ r['gs_link'] }}'>Google Scholar</a> | <a href='{{ r['sci_hub_link'] }}'>Sci-Hub</a></li>{% endfor %}</ul>", results=results, query=query, email=email, year=year, country=country, lang=lang)

@app.route('/sources')
def sources():
    lang = request.args.get('lang', 'ar')
    return render_template_string("<h1>🌍 مصادر البحث العلمي</h1><ul><li><a href='https://scholar.google.com'>Google Scholar</a></li><li><a href='https://sci-hub.se'>Sci-Hub</a></li><li><a href='https://pubmed.ncbi.nlm.nih.gov'>PubMed</a></li></ul>", lang=lang)

@app.route('/sessions')
def sessions():
    lang = request.args.get('lang', 'ar')
    c.execute("SELECT id, query, date FROM searches ORDER BY date DESC LIMIT 20")
    rows = c.fetchall()
    html = "<h1>📑 الجلسات السابقة</h1><ul>"
    for row in rows:
        html += f"<li><a href='/session/{row[0]}'>{row[1]} - {row[2]}</a></li>"
    html += "</ul><a href='/'>⬅️ رجوع</a>"
    return html

@app.route('/session/<int:session_id>')
def view_session(session_id):
    c.execute("SELECT sentence, citation, doi, gs_link, sci_hub_link FROM results WHERE search_id=?", (session_id,))
    rows = c.fetchall()
    html = f"<h2>📄 نتائج الجلسة رقم {session_id}</h2><ul>"
    for s, cit, doi, gs, scihub in rows:
        html += f"<li><b>{s}</b><br><i>{cit}</i><br>DOI: {doi}<br><a href='{gs}' target='_blank'>Google Scholar</a> | <a href='{scihub}' target='_blank'>Sci-Hub</a><hr></li>"
    html += "</ul><a href='/sessions'>⬅️ جميع الجلسات</a>"
    return html

if __name__ == '__main__':
    app.run(debug=True, port=5000, use_reloader=False)
