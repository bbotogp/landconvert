Yemen Land Converter v2 with high compression placeholder.
