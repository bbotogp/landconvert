class LandConverter:
    def convert(self, v, f_unit, t_unit, governorate=None):
        return v*100  # dummy
